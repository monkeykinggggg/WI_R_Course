# GGPlot2_Part2_Modern

Modernized swirl lesson based on the original `GGPlot2_Part2`, updated to avoid the most visible ggplot2 deprecation warnings and cross-platform font issues.

## Main updates
- Replaced the opening `qplot()` refresher with a direct layered `ggplot()` call.
- Replaced `size=` for lines inside `geom_smooth()` with `linewidth=`.
- Replaced `theme_bw(base_family = "Times")` with `theme_bw(base_family = "sans")` to avoid Windows font warnings.
- Kept the overall lesson flow, datasets, and teaching goals as close as possible to the original lesson.

## Suggested folder name inside a swirl course
`GGPlot2_Part2_Modern`

## Files included
- lesson
- initLesson.R
- dependson.txt
- customTests.R
- clearPlot.R