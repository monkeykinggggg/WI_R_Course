# GGPlot2_Part1_Modern

A modernized version of the original swirl lesson `GGPlot2_Part1`.

## What changed
- Replaced the qplot()-driven workflow with layered ggplot() commands.
- Kept the same broad learning arc and similar visual outcomes where practical.
- Left a brief historical mention of qplot(), but the exercises now teach the current recommended style.
- Review questions at the end were updated to reflect modern ggplot2 usage.

## Files
- lesson
- initLesson.R
- dependson.txt
- customTests.R
- clearPlot.R